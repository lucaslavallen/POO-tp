 import java.util.ArrayList;
 import java.util.Scanner;
    
    public class Punto3{}
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
        }
        System.out.print("Ingrese una palabra: ");//ingresa una palabra
            String palabra = scanner.nextLine();// scaner la lee
            
            ArrayList<Character> letras = new ArrayList<>();//creamos una lista
            
          for (int i=0,i<length(palabra),i++);{
            letras.add(palabra.charAt(i));
           }
boolean polindromo=false;
           while (letras (l)==letras (length(letras)-l));{
             boolean polindromo=true;
           }
        

if (polindromo=true);{
    System.out.print("la palabra es un polindromo");}
  else {
    System.out.print("no es un polindromo");
  }
}