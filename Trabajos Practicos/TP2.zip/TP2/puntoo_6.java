public enum punto_6{
    public class Main {
        public class Entero {
            private Integer numero;
            //constructor de la clase Enteros
            public Entero(Integer numero) {
            super();
            this.numero = numero;
            }
            public Integer getNumero() {
            return numero;
            }
            public void setNumero(Integer numero) {
            this.numero = numero;
            }
            //calcula el cuadrado de n
            public Long cuadrado(){
            return numero*numero;
            }
            public Integer par()  {
                if this.numero%this.numero ==0 {
                    sistem.out.print "el numero es par";}
                else sistem.out.print "el numero es impar"
                }
                
            }
            public Integer calcularFactorial(){
                public static long calcularFactorial(int n) {
                    if (n == 0) {
                        return 1;
                    } else {
                        return n * calcularFactorial(n - 1);
                    }
                    
            }
        }
        ```
            }
            
                
            }
            
        }
}   }