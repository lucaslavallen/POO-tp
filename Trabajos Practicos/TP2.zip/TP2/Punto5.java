public enum punto_5{
    public class Punto5 {
        public static void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            for (int i = 1; i <= 5; i++) {
                System.out.println("Ingrese el nombre del empleado ");
                    String nombre = scanner.nextLine();

                System.out.println("Ingrese el sueldo del empleado (redondo) ");
                double sueldo = (scanner.nextLine);

                int sueldoMasAlto = 0 ;
                string empleadoMasGana = "";

                if (sueldo > sueldoMasAlto) {
                    sueldoMasAlto = sueldo;
                    empleadoMasGana = nombre;
                    }
                }

            }
        }
        
    }
}


